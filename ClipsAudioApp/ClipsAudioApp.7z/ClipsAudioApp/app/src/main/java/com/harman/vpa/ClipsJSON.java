package com.harman.vpa;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.harman.vpa.clips.CLIPSException;
import com.harman.vpa.clips.Environment;
import com.harman.vpa.clips.FactAddressValue;
import com.harman.vpa.clips.LexemeValue;
import com.harman.vpa.clips.MultifieldValue;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class ClipsJSON extends AppCompatActivity
{
    String lastAnswer;
    ArrayList<String> variableAsserts;
    ArrayList<String> priorAnswers;
    String relationAsserted;
    String audio_down = "{\n"+
            "\"EVENT_NAME\": \"intentRecognized\",\n"+
            "\"CONFIDENCE\": \"0.546827\",\n"+
            "\"QUERY\": \"turn volume down\",\n"+
            "\"DOMAIN\": \"CAR\",\n"+
            "\"INTENT\": \"audio-settings-down\",\n"+
            "\"TAGS\": [{\n"+
            "\"ENTITY\": \"turn\", \"TAG\": \"action\""+
            "}, {\n"+
            "\"ENTITY\": \"volume\","+
            "\"TAG\": \"param\""+
            "}, {\n"+
            "\"ENTITY\": \"down\","+
            "\"TAG\": \"downAction\""+
            "}]\n"+
            "}";
    String audio_up = "{\n" +
            "               \"EVENT_NAME\": \"intentRecognized\",\n" +
            "               \"CONFIDENCE\": \"0.843412\",\n" +
            "               \"QUERY\": \"increase the volume\",\n" +
            "               \"DOMAIN\": \"CAR\",\n" +
            "               \"INTENT\": \"audio-settings-up\",\n" +
            "               \"TAGS\": [{\n" +
            "                              \"ENTITY\": \"increase\",\n" +
            "                              \"TAG\": \"incValueModifier\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"the\",\n" +
            "                              \"TAG\": \"other\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"volume\",\n" +
            "                              \"TAG\": \"param\"\n" +
            "               }]\n" +
            "}";
    String audio_set = "{\n" +
            "               \"EVENT_NAME\": \"intentRecognized\",\n" +
            "               \"CONFIDENCE\": \"0.795601\",\n" +
            "               \"QUERY\": \"can you please set the treble to six\",\n" +
            "               \"DOMAIN\": \"CAR\",\n" +
            "               \"INTENT\": \"audio-settings-set\",\n" +
            "               \"TAGS\": [{\n" +
            "                              \"ENTITY\": \"can\",\n" +
            "                              \"TAG\": \"other\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"you\",\n" +
            "                              \"TAG\": \"personRef\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"please\",\n" +
            "                              \"TAG\": \"requestTerm\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"set\",\n" +
            "                              \"TAG\": \"setAction\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"the\",\n" +
            "                              \"TAG\": \"other\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"treble\",\n" +
            "                              \"TAG\": \"param\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"to\",\n" +
            "                              \"TAG\": \"other\"\n" +
            "               }, {\n" +
            "                              \"ENTITY\": \"six\",\n" +
            "                              \"TAG\": \"number\"\n" +
            "               }]\n" +
            "}";
    private enum InterviewState
    {
        GREETING,
        CONCLUSION
    };
    InterviewState interviewState;
    boolean isExecuting = false;
    Thread executionThread;
    Environment clips = new Environment();
    TextView displayText;
    Button parseButton;
    InputStream is1 = null;
    InputStream is2 = null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        parseButton = findViewById(R.id.buttonParse);
        displayText = findViewById(R.id.textResult);
        variableAsserts = new ArrayList<String>();

       /* //JSON objects for testing purposes
        JSONObject obj = null;
        JSONObject obj2 = null;
        JSONArray arr = null;
        try {
            //obj = new JSONObject(audio_down);
            obj = new JSONObject(audio_up);
            Log.e("JSON", "Intent = " + obj.getString("INTENT"));
            arr = obj.getJSONArray("TAGS");
            for (int i = 0; i < arr.length(); i++) {
                obj2 = arr.getJSONObject(i);
                if (obj2.getString("TAG").equals("param"))
                    Log.e("JSON", "Param = " + obj2.getString("ENTITY"));
                if (obj2.getString("TAG").equals("number"))
                    Log.e("JSON", "Param = " + obj2.getString("ENTITY"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        try {
            //autoResources = ResourceBundle.getBundle("AutoResources");
            //Toast.makeText(this, autoResources.getString("AutoDemo"), Toast.LENGTH_LONG);
            Log.e("CLIPS", "Get audioControl_noTemplate.clp from assets");
            is1 = getResources().getAssets().open("audioControl_noTemplate.clp");
            //is1 = autoResources.open("audioControl.clp");
            Log.e("CLIPS", "Loading audioControl_noTemplate.clp from inputstream");
            clips.loadFromInputStream(is1);
            Log.e("CLIPS", "Get audioControl_en.clp from assets");
            is2 = getResources().getAssets().open("audioControl_en.clp");
            //is2 = autoResources.open("audioControl_en.clp");
            Log.e("CLIPS", "Loading audioControl_en.clp from inputstream");
            clips.loadFromInputStream(is2);
            Log.e("CLIPS", "Loading done");

            processRules();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (is1 != null)
                    is1.close();
                if (is2 != null)
                    is2.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }

        }
    }

    private void processRules() throws CLIPSException
    {
        Log.e("CLIPS","processRules");
        clips.reset();

        Log.e("CLIPS","reset done.");

        //log the facts asserted
        Log.e("CLIPS","Asserted Facts");

        for (String factString : variableAsserts)
        {
            Log.e("CLIPS",factString);
            String assertCommand = "(assert " + factString + ")";
            clips.eval(assertCommand);
        }

        Log.e("CLIPS","assert command");

        runAuto();
    }

    public void runAuto()
    {
        Runnable runThread =
                new Runnable()
                {
                    public void run()
                    {
                        try
                        { clips.run(); }
                        catch (CLIPSException e)
                        { e.printStackTrace(); }


                        Handler h = new Handler(Looper.getMainLooper());
                        h.post(
                                new Runnable()
                                {
                                    public void run()
                                    {
                                        try
                                        { handleResponse(); }
                                        catch (Exception e)
                                        { e.printStackTrace(); }
                                    }
                                });
                    }
                };

        isExecuting = true;

        executionThread = new Thread(runThread);

        executionThread.start();
    }

    private void handleResponse() throws Exception
    {
        FactAddressValue fv = clips.findFact("UI-state");

        Log.e("CLIPS","findFact1");
        Log.e("CLIPS", "state slotvalue : "+ fv.getSlotValue("state").toString());
        Log.e("CLIPS","findFact2");
        if (fv.getSlotValue("state").toString().equals("conclusion"))
        {
            interviewState = InterviewState.CONCLUSION;
            displayText.setVisibility(View.VISIBLE);
            parseButton.setText("Restart");

        }
        else if (fv.getSlotValue("state").toString().equals("greeting"))
        {
            parseButton.setText("process JSON");
            interviewState = InterviewState.GREETING;
            displayText.setVisibility(View.INVISIBLE);

        }

        String theText = fv.getSlotValue("display").getValue().toString();
        displayText.setText(theText);
        relationAsserted = ((LexemeValue) fv.getSlotValue("relation-asserted")).getValue();
        executionThread = null;
        isExecuting = false;

       /* MultifieldValue damf = (MultifieldValue) fv.getSlotValue("display-answers");
        MultifieldValue vamf = (MultifieldValue) fv.getSlotValue("valid-answers");

        MultifieldValue damf2 = (MultifieldValue) fv.getSlotValue("display-answers2");
        MultifieldValue vamf2 = (MultifieldValue) fv.getSlotValue("valid-answers2");
        String selected = fv.getSlotValue("response").toString();*/

        //RadioButton firstButton = null;


        /*for (int i = 0; i < damf.size(); i++)
        {
            LexemeValue da = (LexemeValue) damf.get(i);
            LexemeValue va = (LexemeValue) vamf.get(i);
            Log.e("CLIPS","da = "+da.toString());
            Log.e("CLIPS","va = "+va.toString());
            String buttonName, buttonText, buttonAnswer;

            buttonName = da.getValue();
            buttonText = buttonName.substring(0,1).toUpperCase() + buttonName.substring(1);
            buttonAnswer = va.getValue();



        }

        for (int i = 0; i < damf2.size(); i++)
        {
            LexemeValue da = (LexemeValue) damf2.get(i);
            LexemeValue va = (LexemeValue) vamf2.get(i);
            Log.e("CLIPS","da = "+da.toString());
            Log.e("CLIPS","va = "+va.toString());
            String buttonName, buttonText, buttonAnswer;

            buttonName = da.getValue();
            buttonText = buttonName.substring(0,1).toUpperCase() + buttonName.substring(1);
            buttonAnswer = va.getValue();

            Log.e("CLIPS","Radio Value : " +buttonAnswer);
            RadioButton rButton = new RadioButton(mContext);
            rButton.setText(buttonAnswer);
            params.addView(rButton);
            if (((lastAnswer != null) && buttonAnswer.equals(lastAnswer)) ||
                    ((lastAnswer == null) && buttonAnswer.equals(selected)))
            { params.check(rButton.getId()); }
            else
            {  }
        }

        Log.e("CLIPS","Added Choices");
        Log.e("CLIPS","Child Count : "+params.getChildCount());
        if (params.getChildCount() == 1) {

            params.check(params.getChildAt(0).getId());
        }

        relationAsserted = ((LexemeValue) fv.getSlotValue("relation-asserted")).getValue();
        String theText = fv.getSlotValue("display").getValue().toString();
        displayText.setText(theText);

        //display text in paramText if given
        theText = fv.getSlotValue("display2").getValue().toString();
        if(theText != "none")
            amountText.setText(theText);

        //display text in amountText if given
        theText = fv.getSlotValue("display3").getValue().toString();
        if(theText != "none")
            paramText.setText(theText);*/

    }

    public void processJSONresponse(View v) throws Exception
    {
        if (isExecuting) return;

        //get the tags from JSON string
        JSONObject obj1;
        JSONArray arr;


        String theString;
        String Intent ;   //get the intent from json


        //choices.setVisibility(View.VISIBLE);
        lastAnswer = null;
        switch (interviewState)
        {
            /* Handle Next button. */
            case GREETING:
                obj1 = new JSONObject(audio_up);  //pass the JSON tag string in the constructor
                arr = obj1.getJSONArray("TAGS");
                Intent = obj1.getString("INTENT"); //Value of intent from JSON
                theString = "(intent "+Intent+")";
                variableAsserts.add(theString);

                //Add everything from tags array into variable asserts
                for(int i=0;i<arr.length();i++){
                    JSONObject obj2 = arr.getJSONObject(i);
                    theString = "("+obj2.getString("TAG")+" "+obj2.getString("ENTITY")+")";
                    variableAsserts.add(theString);
                    /*if(obj2.getString("TAG").equals("param"))
                        Param = obj2.getString("ENTITY");
                    if(obj2.getString("TAG").equals("number"))
                        Number = obj2.getString("ENTITY");*/
                }
                //theString = "(" + relationAsserted + " (intent " +  Intent + ") (num "+ Number + ") (param "+Param+"))";
                //variableAsserts.add(theString);
                //priorAnswers.add(theAnswer);
                break;

           /* case INTENT:
                theAnswerIntent = ((RadioButton) findViewById(choices.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theString = "(" + relationAsserted + " (intent " +  theAnswerIntent + "))";
                Log.e("CLIPS","theString Value INTENT");
                Log.e("CLIPS",theString);
                variableAsserts.add(theString);
                priorAnswers.add(theAnswerIntent);
                break;

            case SLOT:
                theAnswerSlots[0] = amount.getText().toString();
                if(theAnswerSlots[0].equals(""))
                    theAnswerSlots[0] = "1";
                theAnswerSlots[1] = ((RadioButton) findViewById(choices.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theString = "(" + relationAsserted + " (intent " +  theAnswerIntent + ") (num "+theAnswerSlots[0] + ") (param "+theAnswerSlots[1]+"))";
                variableAsserts.add(theString);
                //priorAnswers.add(theAnswerSlots[0]);
                priorAnswers.add(theAnswerSlots[1]);
                break;

            case TAGS:
                theAnswerIntent = ((RadioButton) findViewById(choices.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theAnswerSlots[0] = amount.getText().toString();
                if(theAnswerSlots[0].equals(""))
                    theAnswerSlots[0] = "1";
                theAnswerSlots[1] = ((RadioButton) findViewById(params.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theString = "(" + relationAsserted + " (intent " +  theAnswerIntent + ") (num "+theAnswerSlots[0] + ") (param "+theAnswerSlots[1]+"))";
                variableAsserts.add(theString);
                //priorAnswers.add(theAnswerSlots[0]);
                priorAnswers.add(theAnswerSlots[1]);
                break;*/
            /* Handle Restart button. */
            case CONCLUSION:
                variableAsserts.clear();
                //priorAnswers.clear();
                break;
        }

        processRules();
    }
}
