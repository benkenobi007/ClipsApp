package com.harman.vpa.clips;

public interface PeriodicCallback 
  {
   public void periodicCallback();
  }
