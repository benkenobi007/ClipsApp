package com.harman.vpa;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.harman.vpa.clips.CLIPSException;
import com.harman.vpa.clips.Environment;
import com.harman.vpa.clips.FactAddressValue;
import com.harman.vpa.clips.LexemeValue;
import com.harman.vpa.clips.MultifieldValue;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    /*static {
        System.loadLibrary("CLIPSJNI");
    }*/

    String audio_down = "{\n"+
                    "\"EVENT_NAME\": \"intentRecognized\",\n"+
                    "\"CONFIDENCE\": \"0.546827\",\n"+
                    "\"QUERY\": \"turn volume down\",\n"+
                    "\"DOMAIN\": \"CAR\",\n"+
                    "\"INTENT\": \"audio-settings-down\",\n"+
                    "\"TAGS\": [{\n"+
                    "\"ENTITY\": \"turn\", \"TAG\": \"action\""+
                "}, {\n"+
                    "\"ENTITY\": \"volume\","+
                            "\"TAG\": \"param\""+
                "}, {\n"+
                    "\"ENTITY\": \"down\","+
                            "\"TAG\": \"downAction\""+
                "}]\n"+
                "}";
    private enum InterviewState
    {
        GREETING,
        INTENT,
        SLOT,
        TAGS,
        CONCLUSION
    };

    Context mContext;
    Environment clips;
    boolean isExecuting = false;
    Thread executionThread;
    String lastAnswer;
    String relationAsserted;
    String theAnswerIntent;  //Stores the intent
    String theAnswerSlots[] = new String[2];  //Stores the num at index 0 and param at index 1
    ArrayList<String> variableAsserts;
    ArrayList<String> priorAnswers;
    //ResourceBundle autoResources;
    AssetManager autoResources;
    InterviewState interviewState;
    TextView displayText, paramText, amountText;
    EditText amount;
    Button buttonPrev, buttonNext;
    RadioGroup choices, params;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        JSONObject obj;
        JSONObject obj2;
        JSONArray arr;
        try {
            obj = new JSONObject(audio_down);
            Log.e("JSON","Intent = "+obj.getString("INTENT"));
            arr = obj.getJSONArray("TAGS");
            for(int i=0;i<arr.length();i++){
                obj2 = arr.getJSONObject(i);
                if(obj2.getString("TAG").equals("param"))
                    Log.e("JSON","Param = "+obj2.getString("ENTITY"));
                if(obj2.getString("TAG").equals("number"))
                    Log.e("JSON","Param = "+obj2.getString("ENTITY"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        autoResources = mContext.getAssets();
        displayText = findViewById(R.id.displayText);
        paramText = findViewById(R.id.paramText);
        amountText = findViewById(R.id.amountText);
        amount = findViewById(R.id.numberAmt);
        buttonPrev = findViewById(R.id.buttonPrev);
        buttonNext = findViewById(R.id.buttonNext);
        choices = findViewById(R.id.radiogroupChoices);
        params = findViewById(R.id.radioGroupParams);

        variableAsserts = new ArrayList<String>();
        priorAnswers = new ArrayList<String>();

        clips = new Environment();
        InputStream is1 = null;
        InputStream is2 = null;
        try {
            //autoResources = ResourceBundle.getBundle("AutoResources");
            //Toast.makeText(this, autoResources.getString("AutoDemo"), Toast.LENGTH_LONG);
            Log.e("CLIPS","Get audioControl.clp from assets");
            is1 = getResources().getAssets().open("audioControl.clp");
            //is1 = autoResources.open("audioControl.clp");
            Log.e("CLIPS","Loading audioControl.clp from inputstream");
            clips.loadFromInputStream(is1);
            Log.e("CLIPS","Get audioControl_en.clp from assets");
            is2 = getResources().getAssets().open("audioControl_en.clp");
            //is2 = autoResources.open("audioControl_en.clp");
            Log.e("CLIPS","Loading audioControl_en.clp from inputstream");
            clips.loadFromInputStream(is2);
            Log.e("CLIPS","Loading done");

            processRules();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (is1 != null)
                    is1.close();
                if (is2 != null)
                    is2.close();
            }  catch (Exception e2) {
                e2.printStackTrace();
            }
        }

        // Example of a call to a native method
        //TextView tv = (TextView) findViewById(R.id.sample_text);
        //tv.setText(stringFromJNI());
    }

    /****************/
    /* processRules */
    /****************/
    private void processRules() throws CLIPSException
    {
        Log.e("CLIPS","processRules");
        clips.reset();

        Log.e("CLIPS","reset done.");

        //log the facts asserted
        Log.e("CLIPS","Asserted Facts");

        for (String factString : variableAsserts)
        {
            Log.e("CLIPS",factString);
            String assertCommand = "(assert " + factString + ")";
            clips.eval(assertCommand);
        }

        Log.e("CLIPS","assert command");

        runAuto();
    }

    /********************/
    /* nextButtonAction */
    /********************/
    public void nextButtonAction(View v) throws CLIPSException
    {
        if (isExecuting) return;
        FactAddressValue fv = clips.findFact("UI-state");
        String theString;

        String theAnswer;        //Blank String in case of greeting

        //choices.setVisibility(View.VISIBLE);
        lastAnswer = null;
        switch (interviewState)
        {
            /* Handle Next button. */
            case GREETING:
                theAnswer = "";
                theString = "(" + relationAsserted + " " +  theAnswer + ")";
                variableAsserts.add(theString);
                priorAnswers.add(theAnswer);
                break;

            case INTENT:
                theAnswerIntent = ((RadioButton) findViewById(choices.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theString = "(" + relationAsserted + " (intent " +  theAnswerIntent + "))";
                Log.e("CLIPS","theString Value INTENT");
                Log.e("CLIPS",theString);
                variableAsserts.add(theString);
                priorAnswers.add(theAnswerIntent);
                break;

            case SLOT:
                theAnswerSlots[0] = amount.getText().toString();
                if(theAnswerSlots[0].equals(""))
                    theAnswerSlots[0] = "1";
                theAnswerSlots[1] = ((RadioButton) findViewById(choices.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theString = "(" + relationAsserted + " (intent " +  theAnswerIntent + ") (num "+theAnswerSlots[0] + ") (param "+theAnswerSlots[1]+"))";
                variableAsserts.add(theString);
                //priorAnswers.add(theAnswerSlots[0]);
                priorAnswers.add(theAnswerSlots[1]);
                break;

            case TAGS:
                theAnswerIntent = ((RadioButton) findViewById(choices.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theAnswerSlots[0] = amount.getText().toString();
                if(theAnswerSlots[0].equals(""))
                    theAnswerSlots[0] = "1";
                theAnswerSlots[1] = ((RadioButton) findViewById(params.getCheckedRadioButtonId())).getText().toString();//TODO: Change to value
                theString = "(" + relationAsserted + " (intent " +  theAnswerIntent + ") (num "+theAnswerSlots[0] + ") (param "+theAnswerSlots[1]+"))";
                variableAsserts.add(theString);
                //priorAnswers.add(theAnswerSlots[0]);
                priorAnswers.add(theAnswerSlots[1]);
                break;
            /* Handle Restart button. */
            case CONCLUSION:
                variableAsserts.clear();
                priorAnswers.clear();
                break;
        }

        processRules();
    }

    /********************/
    /* prevButtonAction */
    /********************/
    public void prevButtonAction(View v) throws CLIPSException
    {
        if (isExecuting) return;
        lastAnswer = priorAnswers.get(priorAnswers.size() - 1);
        Log.e("CLIPS","LastAnswer = "+lastAnswer);
        variableAsserts.remove(variableAsserts.size() - 1);
        priorAnswers.remove(priorAnswers.size() - 1);

        processRules();
    }

    /***********/
    /* runAuto */
    /***********/
    public void runAuto()
    {
        Runnable runThread =
                new Runnable()
                {
                    public void run()
                    {
                        try
                        { clips.run(); }
                        catch (CLIPSException e)
                        { e.printStackTrace(); }


                        Handler h = new Handler(Looper.getMainLooper());
                        h.post(
                                new Runnable()
                                {
                                    public void run()
                                    {
                                        try
                                        { handleResponse(); }
                                        catch (Exception e)
                                        { e.printStackTrace(); }
                                    }
                                });
                    }
                };

        isExecuting = true;

        executionThread = new Thread(runThread);

        executionThread.start();
    }

    /*******************/
    /* handleResponse: */
    /*******************/
    private void handleResponse() throws Exception
    {
        FactAddressValue fv = clips.findFact("UI-state");

        Log.e("CLIPS","findFact1");
        Log.e("CLIPS", "state slotvalue : "+ fv.getSlotValue("state").toString());
        Log.e("CLIPS","findFact2");
        if (fv.getSlotValue("state").toString().equals("conclusion"))
        {
            interviewState = InterviewState.CONCLUSION;
            //buttonNext.setText(autoResources.getString("Restart"));
            buttonNext.setText("Restart");
            buttonPrev.setVisibility(View.VISIBLE);
            choices.setVisibility(View.INVISIBLE);
            params.setVisibility(View.INVISIBLE);
            amount.setVisibility(View.INVISIBLE);
            paramText.setVisibility(View.GONE);
            amountText.setVisibility(View.GONE);
        }
        else if (fv.getSlotValue("state").toString().equals("greeting"))
        {
            interviewState = InterviewState.GREETING;
            buttonNext.setText("Next");
            buttonPrev.setVisibility(View.INVISIBLE);
            choices.setVisibility(View.INVISIBLE);
            params.setVisibility(View.INVISIBLE);
            amount.setVisibility(View.INVISIBLE);
            paramText.setVisibility(View.INVISIBLE);
            amountText.setVisibility(View.GONE);
        }
        else if (fv.getSlotValue("state").toString().equals("intent-selection")){
            interviewState = InterviewState.INTENT;
            buttonNext.setText("Next");
            buttonPrev.setVisibility(View.VISIBLE);
            amount.setVisibility(View.INVISIBLE);
            paramText.setVisibility(View.INVISIBLE);
            choices.setVisibility(View.VISIBLE);
        }
        else if (fv.getSlotValue("state").toString().equals("slot-selection"))
        {
            interviewState = InterviewState.SLOT;
            buttonNext.setText("Next");
            buttonPrev.setVisibility(View.VISIBLE);
            amount.setVisibility(View.VISIBLE);
            paramText.setVisibility(View.VISIBLE);
            choices.setVisibility(View.VISIBLE);
        }
        else if (fv.getSlotValue("state").toString().equals("tag-selection"))
        {
            interviewState = InterviewState.TAGS;
            buttonNext.setText("Next");
            buttonPrev.setVisibility(View.VISIBLE);
            amount.setVisibility(View.VISIBLE);
            paramText.setVisibility(View.VISIBLE);
            amountText.setVisibility(View.VISIBLE);
            choices.setVisibility(View.VISIBLE);
            params.setVisibility(View.VISIBLE);
        }

        Log.e("CLIPS","Removing Choices and params");
        choices.removeAllViews();
        params.removeAllViews();
        //choices.clearCheck();
        Log.e("CLIPS","Removed Choices");
        MultifieldValue damf = (MultifieldValue) fv.getSlotValue("display-answers");
        MultifieldValue vamf = (MultifieldValue) fv.getSlotValue("valid-answers");

        MultifieldValue damf2 = (MultifieldValue) fv.getSlotValue("display-answers2");
        MultifieldValue vamf2 = (MultifieldValue) fv.getSlotValue("valid-answers2");
        String selected = fv.getSlotValue("response").toString();

        //RadioButton firstButton = null;

        Log.e("CLIPS","Radio Buttons : " +damf.size());
        for (int i = 0; i < damf.size(); i++)
        {
            LexemeValue da = (LexemeValue) damf.get(i);
            LexemeValue va = (LexemeValue) vamf.get(i);
            Log.e("CLIPS","da = "+da.toString());
            Log.e("CLIPS","va = "+va.toString());
            String buttonName, buttonText, buttonAnswer;

            buttonName = da.getValue();
            buttonText = buttonName.substring(0,1).toUpperCase() + buttonName.substring(1);
            buttonAnswer = va.getValue();

            Log.e("CLIPS","Radio Value : " +buttonAnswer);
            RadioButton rButton = new RadioButton(mContext);
            rButton.setText(buttonAnswer); // TODO: Change to buttonText
            choices.addView(rButton);
            if (((lastAnswer != null) && buttonAnswer.equals(lastAnswer)) ||
                    ((lastAnswer == null) && buttonAnswer.equals(selected)))
            { choices.check(rButton.getId()); }
            else
            {  }



        }
        Log.e("CLIPS","Added Choices");
        Log.e("CLIPS","Child Count : "+choices.getChildCount());
        if (choices.getChildCount() == 1) {

            choices.check(choices.getChildAt(0).getId());
        }

        for (int i = 0; i < damf2.size(); i++)
        {
            LexemeValue da = (LexemeValue) damf2.get(i);
            LexemeValue va = (LexemeValue) vamf2.get(i);
            Log.e("CLIPS","da = "+da.toString());
            Log.e("CLIPS","va = "+va.toString());
            String buttonName, buttonText, buttonAnswer;

            buttonName = da.getValue();
            buttonText = buttonName.substring(0,1).toUpperCase() + buttonName.substring(1);
            buttonAnswer = va.getValue();

            Log.e("CLIPS","Radio Value : " +buttonAnswer);
            RadioButton rButton = new RadioButton(mContext);
            rButton.setText(buttonAnswer); // TODO: Change to buttonText
            params.addView(rButton);
            if (((lastAnswer != null) && buttonAnswer.equals(lastAnswer)) ||
                    ((lastAnswer == null) && buttonAnswer.equals(selected)))
            { params.check(rButton.getId()); }
            else
            {  }
        }

        Log.e("CLIPS","Added Choices");
        Log.e("CLIPS","Child Count : "+params.getChildCount());
        if (params.getChildCount() == 1) {

            params.check(params.getChildAt(0).getId());
        }

        relationAsserted = ((LexemeValue) fv.getSlotValue("relation-asserted")).getValue();
        String theText = fv.getSlotValue("display").getValue().toString();
        displayText.setText(theText);

        //display text in paramText if given
        theText = fv.getSlotValue("display2").getValue().toString();
        if(theText != "none")
            amountText.setText(theText);

        //display text in amountText if given
        theText = fv.getSlotValue("display3").getValue().toString();
        if(theText != "none")
            paramText.setText(theText);
        executionThread = null;

        isExecuting = false;
    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    //public native String stringFromJNI();
}
